### Please those who want to develop the SC to be better/cool

### Clone this repository
```bash
> git clone https://github.com/KiZakiXD/Wa-Bot
> cd Wa-Bot
```

### Installation (Termux/Ubuntu/Linux)
```bash
> apt install nodejs
> apt install ffmpeg
> npm i
```

### Configuration
* Set configuration on [this](https://github.com/KiZakiXD/Wa-Bot/blob/main/config.js)) file
* Get apikey from [this](https://api.kizakixd.xyz) site
* Join the discussion group [here](https://chat.whatsapp.com/LUzwuA0t9JDBZYMmhS0m91) link

### Run this command when installation is done
```bash
> node index # or npm start
```

# Thanks To
* [`Npc`](https://github.com/erzawife)
* [`KiZakiXD`](https://github.com/kizakixd)
* [`Vania`](https://github.com/fckvania)
* [`Arip`](https://github.com/Akkun3704)

  
